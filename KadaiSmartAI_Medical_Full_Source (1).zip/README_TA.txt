KadaiSmart AI Medical - Flask Source Code
=========================================
Run:
1. Extract ZIP into a folder.
2. Install Python 3.11 or 3.12 and tick "Add Python to PATH".
3. Double-click run_windows.bat.
4. Open http://127.0.0.1:5000

Demo accounts:
Admin: admin / Admin@123
Staff: staff / Staff@123
Change default passwords before using real data. Admin can create users and reset passwords.

Features:
- Admin/Staff login, password hashing, logout, role-based access
- Medicine/product master, batch, expiry date, price and stock threshold
- Barcode and QR label print page (USB scanner keyboard mode supported in billing)
- POS billing, Cash/UPI/Card/Credit selection, printable receipt
- Stock-in entries and stock auto-deduction after successful bill
- Customer records with CUS-0001 IDs and printable QR customer card
- Customer ID/phone lookup in billing
- Sales history, low stock and top-selling reports
- Prescription record log (this demo stores metadata only; it does not upload/store actual prescription files)

Barcode / QR:
- Product labels use browser libraries loaded from CDN, so internet is needed to render the graphics.
- USB scanner should type the barcode into the scan field and send Enter.
- QR code stores product code or customer ID only.
- Test scanner, label printer, receipt printer and database backup before real use.

Security / compliance:
- This is an MVP/demo, not production-ready.
- Change demo credentials, set KADAISMART_SECRET and configure backups.
- Prescription upload storage, GST-compliant invoicing, CSRF protection, audit logs, expiry alerts, supplier purchasing workflow, multi-PC sync and payment verification are not fully implemented.
- Follow applicable pharmacy laws and prescription requirements; software does not verify medical appropriateness.
