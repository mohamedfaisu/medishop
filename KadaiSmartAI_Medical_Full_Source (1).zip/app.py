import os, sqlite3, json
from datetime import datetime, date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(ROOT,"kadaismart_medical.db")
app=Flask(__name__)
app.secret_key=os.environ.get("KADAISMART_SECRET","change-this-secret-before-production")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

def connect():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c

def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if not session.get("user_id"): return redirect(url_for("login",next=request.path))
        return fn(*a,**kw)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if not session.get("user_id"): return redirect(url_for("login",next=request.path))
        if session.get("role")!="admin":
            flash("Admin access required.","error"); return redirect(url_for("dashboard"))
        return fn(*a,**kw)
    return wrapped

def init_db():
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','staff')),active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,barcode TEXT UNIQUE,name TEXT NOT NULL,category TEXT DEFAULT 'Others',unit TEXT DEFAULT 'pack',batch TEXT DEFAULT '',expiry TEXT DEFAULT '',cost REAL DEFAULT 0,price REAL NOT NULL,stock REAL DEFAULT 0,low_stock REAL DEFAULT 5,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_code TEXT UNIQUE NOT NULL,name TEXT NOT NULL,phone TEXT DEFAULT '',address TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,bill_no TEXT UNIQUE NOT NULL,customer_code TEXT DEFAULT '',customer_name TEXT DEFAULT 'Walk-in Customer',subtotal REAL NOT NULL,discount REAL DEFAULT 0,total REAL NOT NULL,payment TEXT DEFAULT 'Cash',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER NOT NULL,code TEXT,name TEXT,qty REAL,price REAL,amount REAL,batch TEXT DEFAULT '',expiry TEXT DEFAULT '',FOREIGN KEY(sale_id) REFERENCES sales(id),FOREIGN KEY(product_id) REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS stock_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,qty REAL NOT NULL,note TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(product_id) REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS prescriptions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_name TEXT NOT NULL,phone TEXT DEFAULT '',doctor TEXT DEFAULT '',notes TEXT DEFAULT '',file_name TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        for username,pw,role in [("admin",os.environ.get("KADAISMART_ADMIN_PASSWORD","Admin@123"),"admin"),("staff",os.environ.get("KADAISMART_STAFF_PASSWORD","Staff@123"),"staff")]:
            if not c.execute("SELECT id FROM users WHERE username=?",(username,)).fetchone():
                c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",(username,generate_password_hash(pw),role))
        if c.execute("SELECT COUNT(*) FROM products").fetchone()[0]==0:
            sample=[
            ("MED1001","1001001","Paracetamol 500mg","Tablet","strip","B001","2027-12-31",8,12,150,20),
            ("MED1002","1001002","Amoxicillin 500mg","Capsule","strip","A125","2027-10-31",32,48,85,30),
            ("MED1003","1001003","Cetirizine 10mg","Tablet","strip","C203","2027-08-31",10,18,120,20),
            ("MED1004","1001004","Azithromycin 500mg","Tablet","strip","A500","2027-11-30",50,75,30,10),
            ("MED1005","1001005","Pantoprazole 40mg","Tablet","strip","P001","2027-09-30",12,22,60,10),
            ("MED1006","1001006","ORS Powder","Sachet","packet","O451","2027-06-30",8,15,200,30),
            ("MED1007","1001007","Cough Syrup 100ml","Syrup","bottle","S010","2027-05-31",35,60,45,10),
            ("MED1008","1001008","Vitamin C 500mg","Tablet","strip","V320","2027-12-31",15,25,90,15),
            ("MED1009","1001009","Calcium + D3","Tablet","strip","D003","2027-10-31",70,110,40,10),
            ("MED1010","1001010","Diclofenac Gel","Gel","tube","G010","2027-08-31",52,85,25,8)]
            c.executemany("INSERT INTO products(code,barcode,name,category,unit,batch,expiry,cost,price,stock,low_stock) VALUES(?,?,?,?,?,?,?,?,?,?,?)",sample)

@app.route("/login",methods=["GET","POST"])
def login():
    if session.get("user_id"): return redirect(url_for("dashboard"))
    if request.method=="POST":
        u=request.form.get("username","").strip(); p=request.form.get("password","")
        with connect() as c: user=c.execute("SELECT * FROM users WHERE username=? AND active=1",(u,)).fetchone()
        if user and check_password_hash(user["password_hash"],p):
            session.clear(); session.update(user_id=user["id"],username=user["username"],role=user["role"])
            dest=request.args.get("next","")
            return redirect(dest if dest.startswith("/") and not dest.startswith("//") else url_for("dashboard"))
        flash("Username or password incorrect.","error")
    return render_template("login.html")

@app.route("/logout",methods=["POST"])
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    with connect() as c:
        total_products=c.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        low=c.execute("SELECT COUNT(*) FROM products WHERE stock<=low_stock").fetchone()[0]
        customers=c.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        today=c.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at)=date('now','localtime')").fetchone()[0]
        bills=c.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 5").fetchall()
        lows=c.execute("SELECT * FROM products WHERE stock<=low_stock ORDER BY stock LIMIT 8").fetchall()
    return render_template("dashboard.html",total_products=total_products,low=low,customers=customers,today=today,bills=bills,lows=lows)

@app.route("/products",methods=["GET","POST"])
@admin_required
def products():
    if request.method=="POST":
        try:
            vals=[request.form.get(k,"").strip() for k in ["code","barcode","name","category","unit","batch","expiry"]]
            code,barcode,name,category,unit,batch,expiry=vals
            cost=float(request.form.get("cost",0)); price=float(request.form.get("price",0)); stock=float(request.form.get("stock",0)); low=float(request.form.get("low_stock",5))
            if not code or not name or price<0 or min(cost,stock,low)<0: raise ValueError()
            with connect() as c:
                c.execute("INSERT INTO products(code,barcode,name,category,unit,batch,expiry,cost,price,stock,low_stock) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(code,barcode or code,name,category or "Others",unit or "pack",batch,expiry,cost,price,stock,low))
            flash("Medicine added.","success")
        except sqlite3.IntegrityError: flash("Product code or barcode already exists.","error")
        except (ValueError,TypeError): flash("Check product details and numbers.","error")
        return redirect(url_for("products"))
    q=request.args.get("q","")
    with connect() as c: rows=c.execute("SELECT * FROM products WHERE name LIKE ? OR code LIKE ? OR COALESCE(barcode,'') LIKE ? ORDER BY name",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    return render_template("products.html",rows=rows,q=q)

@app.route("/api/product/<path:code>")
@login_required
def product_api(code):
    with connect() as c: p=c.execute("SELECT * FROM products WHERE code=? OR barcode=?",(code,code)).fetchone()
    if not p: return jsonify(ok=False,message="Medicine not found"),404
    return jsonify(ok=True,id=p["id"],code=p["code"],barcode=p["barcode"],name=p["name"],price=p["price"],stock=p["stock"],batch=p["batch"],expiry=p["expiry"],category=p["category"])

@app.route("/labels")
@admin_required
def labels():
    with connect() as c: rows=c.execute("SELECT * FROM products ORDER BY name").fetchall()
    return render_template("labels.html",rows=rows)

@app.route("/stock",methods=["GET","POST"])
@admin_required
def stock():
    if request.method=="POST":
        try:
            pid=int(request.form["product_id"]); qty=float(request.form["qty"]); note=request.form.get("note","").strip()
            if qty<=0: raise ValueError()
            with connect() as c:
                if not c.execute("SELECT id FROM products WHERE id=?",(pid,)).fetchone(): raise ValueError()
                c.execute("UPDATE products SET stock=stock+? WHERE id=?",(qty,pid))
                c.execute("INSERT INTO stock_entries(product_id,qty,note) VALUES(?,?,?)",(pid,qty,note))
            flash("Stock updated.","success")
        except (ValueError,KeyError): flash("Select medicine and enter a valid quantity.","error")
        return redirect(url_for("stock"))
    with connect() as c:
        rows=c.execute("SELECT * FROM products ORDER BY name").fetchall()
        entries=c.execute("SELECT se.*,p.name,p.code FROM stock_entries se JOIN products p ON p.id=se.product_id ORDER BY se.id DESC LIMIT 25").fetchall()
    return render_template("stock.html",rows=rows,entries=entries)

@app.route("/customers",methods=["GET","POST"])
@login_required
def customers():
    if request.method=="POST":
        name=request.form.get("name","").strip(); phone=request.form.get("phone","").strip(); address=request.form.get("address","").strip()
        if not name: flash("Customer name is required.","error"); return redirect(url_for("customers"))
        with connect() as c:
            if phone and c.execute("SELECT id FROM customers WHERE phone=? AND phone<>''",(phone,)).fetchone():
                flash("Phone number already exists.","error"); return redirect(url_for("customers"))
            n=c.execute("SELECT COALESCE(MAX(id),0)+1 FROM customers").fetchone()[0]; code=f"CUS-{n:04d}"
            c.execute("INSERT INTO customers(customer_code,name,phone,address) VALUES(?,?,?,?)",(code,name,phone,address))
        flash("Customer created: "+code,"success"); return redirect(url_for("customers"))
    q=request.args.get("q","")
    with connect() as c: rows=c.execute("SELECT * FROM customers WHERE customer_code LIKE ? OR name LIKE ? OR phone LIKE ? ORDER BY id DESC",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    return render_template("customers.html",rows=rows,q=q)

@app.route("/api/customer/<path:code>")
@login_required
def customer_api(code):
    with connect() as c: x=c.execute("SELECT * FROM customers WHERE customer_code=? OR phone=?",(code,code)).fetchone()
    if not x: return jsonify(ok=False,message="Customer not found"),404
    return jsonify(ok=True,code=x["customer_code"],name=x["name"],phone=x["phone"],address=x["address"])

@app.route("/customers/<int:cid>/card")
@login_required
def customer_card(cid):
    with connect() as c: x=c.execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone()
    if not x: return "Customer not found",404
    return render_template("customer_card.html",customer=x)

@app.route("/billing")
@login_required
def billing():
    with connect() as c: rows=c.execute("SELECT * FROM products WHERE stock>0 ORDER BY name").fetchall()
    return render_template("billing.html",rows=rows)

@app.route("/checkout",methods=["POST"])
@login_required
def checkout():
    try:
        cart=json.loads(request.form.get("cart","[]")); ccode=request.form.get("customer_code","").strip()
        cname=request.form.get("customer_name","").strip() or "Walk-in Customer"; payment=request.form.get("payment","Cash")
        discount=float(request.form.get("discount",0))
        if payment not in ("Cash","UPI","Card","Credit"): payment="Cash"
        if not cart or discount<0: raise ValueError("Cart or discount is invalid.")
        with connect() as c:
            cust=None
            if ccode:
                cust=c.execute("SELECT * FROM customers WHERE customer_code=? OR phone=?",(ccode,ccode)).fetchone()
                if not cust: raise ValueError("Customer ID / phone not found.")
                cname=cust["name"]; ccode=cust["customer_code"]
            lines=[]; subtotal=0
            for item in cart:
                pid=int(item["id"]); qty=float(item["qty"])
                if qty<=0: raise ValueError("Invalid quantity.")
                p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
                if not p or p["stock"]<qty: raise ValueError("Insufficient stock for "+(p["name"] if p else "medicine"))
                amount=round(qty*p["price"],2); subtotal+=amount; lines.append((p,qty,amount))
            if discount>subtotal: raise ValueError("Discount cannot exceed subtotal.")
            total=round(subtotal-discount,2); billno="MED"+datetime.now().strftime("%y%m%d%H%M%S%f")[-12:]
            sid=c.execute("INSERT INTO sales(bill_no,customer_code,customer_name,subtotal,discount,total,payment) VALUES(?,?,?,?,?,?,?)",(billno,ccode,cname,subtotal,discount,total,payment)).lastrowid
            for p,qty,amount in lines:
                c.execute("INSERT INTO sale_items(sale_id,product_id,code,name,qty,price,amount,batch,expiry) VALUES(?,?,?,?,?,?,?,?,?)",(sid,p["id"],p["code"],p["name"],qty,p["price"],amount,p["batch"],p["expiry"]))
                c.execute("UPDATE products SET stock=stock-? WHERE id=?",(qty,p["id"]))
        return redirect(url_for("receipt",sid=sid))
    except (ValueError,KeyError,TypeError) as e:
        flash(str(e) or "Invalid bill.","error"); return redirect(url_for("billing"))

@app.route("/receipt/<int:sid>")
@login_required
def receipt(sid):
    with connect() as c:
        sale=c.execute("SELECT * FROM sales WHERE id=?",(sid,)).fetchone()
        lines=c.execute("SELECT * FROM sale_items WHERE sale_id=?",(sid,)).fetchall()
    if not sale: return "Bill not found",404
    return render_template("receipt.html",sale=sale,lines=lines)

@app.route("/sales")
@login_required
def sales():
    start=request.args.get("start",date.today().isoformat()); end=request.args.get("end",date.today().isoformat())
    with connect() as c: rows=c.execute("SELECT * FROM sales WHERE date(created_at) BETWEEN ? AND ? ORDER BY id DESC",(start,end)).fetchall()
    return render_template("sales.html",rows=rows,start=start,end=end,total=sum(r["total"] for r in rows))

@app.route("/reports")
@admin_required
def reports():
    with connect() as c:
        lows=c.execute("SELECT * FROM products WHERE stock<=low_stock ORDER BY stock").fetchall()
        best=c.execute("SELECT name,SUM(qty) qty,SUM(amount) amount FROM sale_items GROUP BY product_id ORDER BY qty DESC LIMIT 10").fetchall()
        stockvalue=c.execute("SELECT COALESCE(SUM(stock*cost),0) FROM products").fetchone()[0]
    return render_template("reports.html",lows=lows,best=best,stockvalue=stockvalue)

@app.route("/prescriptions",methods=["GET","POST"])
@admin_required
def prescriptions():
    if request.method=="POST":
        patient=request.form.get("patient_name","").strip()
        if not patient: flash("Patient name required.","error"); return redirect(url_for("prescriptions"))
        with connect() as c:
            c.execute("INSERT INTO prescriptions(patient_name,phone,doctor,notes,file_name) VALUES(?,?,?,?,?)",(patient,request.form.get("phone","").strip(),request.form.get("doctor","").strip(),request.form.get("notes","").strip(),request.form.get("file_name","").strip()))
        flash("Prescription record saved. Upload storage is not enabled in this demo.","success"); return redirect(url_for("prescriptions"))
    with connect() as c: rows=c.execute("SELECT * FROM prescriptions ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("prescriptions.html",rows=rows)

@app.route("/admin/users",methods=["GET","POST"])
@admin_required
def users():
    if request.method=="POST":
        u=request.form.get("username","").strip(); p=request.form.get("password",""); role=request.form.get("role","staff")
        if not u or len(p)<8 or role not in ("admin","staff"): flash("Use a username and password with at least 8 characters.","error")
        else:
            try:
                with connect() as c: c.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",(u,generate_password_hash(p),role))
                flash("User created.","success")
            except sqlite3.IntegrityError: flash("Username already exists.","error")
        return redirect(url_for("users"))
    with connect() as c: rows=c.execute("SELECT id,username,role,active,created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html",rows=rows)

@app.route("/admin/users/<int:uid>/reset",methods=["POST"])
@admin_required
def reset_password(uid):
    p=request.form.get("password","")
    if len(p)<8: flash("Password must be at least 8 characters.","error")
    else:
        with connect() as c: c.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(p),uid))
        flash("Password reset.","success")
    return redirect(url_for("users"))

if __name__=="__main__":
    init_db()
    app.run(host="127.0.0.1",port=5000,debug=False)
